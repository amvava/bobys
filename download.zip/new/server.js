const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

// Port server
const PORT = 3000;

// Serve static files
app.use(express.static('public'));

// Endpoint untuk Server-Sent Events
app.get('/updates', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  // Watch file changes
  const filePath = path.join(__dirname, 'files', 'app.log');
  
  const sendUpdate = () => {
    fs.readFile(filePath, 'utf8', (err, data) => {
      if (err) {
        res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
        return;
      }
      res.write(`data: ${JSON.stringify({ content: data })}\n\n`);
    });
  };

  // Initial send
  sendUpdate();

  // Watch for changes
  const watcher = fs.watch(filePath, (eventType) => {
    if (eventType === 'change') {
      sendUpdate();
    }
  });

  // Cleanup saat koneksi ditutup
  req.on('close', () => {
    watcher.close();
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});